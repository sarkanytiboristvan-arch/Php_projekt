    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Fitness Tracker. Minden jog fenntartva.</p>
        </div>
    </footer>

    <script src="public/js/main.js"></script>
</body>
</html>
